# MoarUnits
A mod that adds more units to Civilization 6

## Re-Use in Other Mods
I'm happy for anything from Moar Units to be re-used and reworked in other mods. Go ahead!

Have fun!
